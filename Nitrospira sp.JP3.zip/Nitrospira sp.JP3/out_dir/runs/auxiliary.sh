rm -rf out_dir/mmseqs/tmp
